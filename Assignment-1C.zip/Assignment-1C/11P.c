int main()
{
    printf("\"\\n\"");
    return 0;
}
