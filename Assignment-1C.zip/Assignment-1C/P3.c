#include<stdio.h>
void main()
{
    printf("\"MySirG\"");
    return 0;
}
