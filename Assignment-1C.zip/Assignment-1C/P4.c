#include<stdio.h>
void main()
{
    int r;
    float a;
    printf("enter a radius");
    scanf("%d",&r);
    a=3.14*r*r;
    printf("area of circle %f",a);
    return 0;
}
