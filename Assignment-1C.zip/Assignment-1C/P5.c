#include<stdio.h>
void main()
{
    printf("\"Hello,Diksha lamba\"");
    return 0;
}
