#include<stdio.h>
#include<conio.h>
int main()
{
    int day,DD,month,MM,year,YYYY,x;
    printf("DD/MM/YYYY");
    scanf("DD-day,MM-month, YYYY-year");
    printf("DD=%d,MM=%d,YYYY=%d",x);
    return 0;
}
