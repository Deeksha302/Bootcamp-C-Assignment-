int main()
{
    printf("\"Hello , Amit kumar\"");
    return 0;
}
