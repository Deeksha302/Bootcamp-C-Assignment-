#include<stdio.h>
int main()
{
    int x=printf("Diksha\0");
  printf(" string length  is %d",x);
   printf("\n");
   return 0;
}


