#include<stdio.h>
int main()
{
    int x,y;
    printf("enter two number");
    scanf("%d%d",&x,&y);
    printf("\"%d:%d\"convered to \"11 hour and 25 minutes\"",x,y);
    return 0;
}
