int main()
{
    int x=printf("ineuron");
    printf("%d",x);
    return 0;
}
