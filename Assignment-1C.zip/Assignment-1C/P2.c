#include<stdio.stdio.h>
int main()
{
    printf("Hello\nstudent");
    return 0;
}
