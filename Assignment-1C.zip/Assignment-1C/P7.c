#include<stdio.h>
int main()
{
    printf("\"%%d\"");
    return 0;
}
