#include<stdio.h>
int main()
{
    int x,c;
    printf("enter any number");
    scanf("%d",&x);
    c=x%10;
    printf("unit digit %d",c);
    return 0;
}
