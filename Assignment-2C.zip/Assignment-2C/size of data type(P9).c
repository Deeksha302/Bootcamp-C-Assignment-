int main()
{
  int a;
  char b;
  float c;
  double d;
  printf("size of  data type int =%d\n",sizeof(a));
   printf("size of  data type char=%d\n",sizeof(b));
    printf("size of  data type float =%d\n",sizeof(c));
     printf("size of  data type double=%d\n",sizeof(d));
      return 0;
}
