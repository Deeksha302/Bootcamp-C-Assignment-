//To convert Dollars into Rupees according (21 April 2020-1rupees=76.23dollar)
 /*#include <stdio.h>
int main(void)
{
int a,b;
printf("Enter amount in Dollars\n");
scanf("%d",&a );
b=a*76.23;
printf("convrt indian rupees=%d\n",b);
return 0;
}*/

/*To convert  Rupees into dollars update(15 August 2022 -1rupees=79.30dollar)*/
/*#include <stdio.h>
int main(void)
{
int a,b;
printf("Enter amount in Rupees\n");
scanf("%d",&a );
b=a/79.30;
printf("convert USA dollar %d\n",b);
return 0;
}*/
