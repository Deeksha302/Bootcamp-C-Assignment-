/*Three digit number sum*/
#include<stdio.h>
int main()
{
    int n,rem,sum=0,x;
    printf("enter a number");
    scanf("%d",&x);
    rem=x%10;
    x=x/10;
    sum=sum+rem;

    rem=x%10;
    x=x/10;
    sum=sum+rem;

    rem=x%10;
    x=x/10;
    sum=sum+rem;
    printf("sum of three digits %d",sum);
    return 0;
}
