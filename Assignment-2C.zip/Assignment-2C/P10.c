/* last digit of a number stored in a variable as zero.*/
#include<stdio.h>
int main()
{
      int n,s,m;
      printf("enter a number");
      scanf("%d",&n);
      s=n/10;
      m=s*10;
      printf("%d",m);
      return 0;
}
