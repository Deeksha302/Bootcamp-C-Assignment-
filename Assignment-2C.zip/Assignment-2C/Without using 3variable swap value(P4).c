#include<stdio.h>
int main()
{
    int a,b;
    printf("enter two number");
    scanf("%d%d",&a,&b);
    /*a=b*a;
    b=a/b;
    a=a/b;*/
    /*or*/
    a=a+b;
    b=a-b;
    a=a-b;
    /*or*/
   /* b=(a+b)-(a=b);*/
    printf("a=%d,b=%d",a,b);
    return 0;
}
