#include<stdio.h>
int main()
{
   /* int  cap;*/
   int small;
    printf("enter ASCII Code");
    scanf("%c",&small);

  /*  for(cap=65;cap<91;cap++) */
    for(small=0;small<226;small++)
         printf("  %c =%d",small,small);
          printf("\n");
          return 0;
}
