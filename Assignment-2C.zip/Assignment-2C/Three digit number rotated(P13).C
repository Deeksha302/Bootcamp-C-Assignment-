#include<stdio.h>
int main()
{
      int n,x,p,q,r;
      printf("enter three digit number");
      scanf("%d",&n);
      p=n/10;
      q=n%10;
      r=q*100+p;
      printf("Three digit number is rotate=%d",r);
      return 0;
}
