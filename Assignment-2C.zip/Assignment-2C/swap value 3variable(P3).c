#include<stdio.h>
int main()
{
    int a,b,c;
printf("enter any number");
scanf("%d%d%d",&a,&b,&c);
    c=a;
    a=b;
    b=c;
    printf("swap number a=%d,b=%d",a,b);
    return 0;
}
