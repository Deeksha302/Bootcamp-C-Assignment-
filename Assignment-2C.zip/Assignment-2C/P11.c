/* Append a digit in the number and print the resulting number. (Example - number=234 and
digit=9 then the resulting number is 2349)*/
#include<stdio.h>
#include<conio.h>
int  main()
{
        int  n=9,x;
      printf("enter a number");
      scanf("%d",&x);
        x=x*10;
        x=x+n;
    printf("%d",x);
    return 0;
}
/*jitni digit ka number append karna hai utne se multiply karna padega -
1 digit no-10 se multiply
2 digit no-100 se multiply
3 digit no-1000 */

