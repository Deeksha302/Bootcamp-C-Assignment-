/*Bitwise operator ka used krne par */
#include<stdio.h>
int main()
{
int n;
printf("enter a number\n");
scanf("%d",&n);
if((n&1)==0)        /*0r (n%2==0)=>simple modulus operator ka use krne par*/
      printf("even number");
else
      printf("odd number");
return 0;
}
