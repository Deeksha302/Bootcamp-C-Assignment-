int main()
{
      int i=1,n,s=0;
      printf("enter n number");
      scanf("%d",&n);
      for(i=1;i<=n;i++)
      s=s+i;
      printf("sum=%d",s);
      return 0;
}
