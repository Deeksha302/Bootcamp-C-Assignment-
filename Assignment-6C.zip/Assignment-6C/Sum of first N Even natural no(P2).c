#include<stdio.h>
int main()
{
      int i,n,s=0;
      printf("enter  n  number");
      scanf("%d",&n);
      for(i=1;i<=n;i++)
     s=s+i*2;
            printf("Sum of N Even natural number=%d",s);
      return 0;
}
