#include<stdio.h>
int main()
{
      int i,n,s=0;
      printf("enter  n  number");
      scanf("%d",&n);
      for(i=1;i<=n;i++)
     s=s+i*i*i;
            printf("Sum of cube N natural number=%d",s);
      return 0;
}
