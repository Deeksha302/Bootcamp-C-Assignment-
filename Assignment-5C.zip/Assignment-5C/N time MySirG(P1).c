int main()
{
      int i=1,n;
      printf("enter a number");
      scanf("%d",&n);
      while(i<=n)
      {
            printf("\nMysirG");
            i++;
      }
      return 0;
}
