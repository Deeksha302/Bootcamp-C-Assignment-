#include<stdio.h>
int main()
{
      int i=1,n;
      printf("enter  n  number");
      scanf("%d",&n);
      while(i<=10)
      {
            printf("%d\t",n*i);
            i++;
      }
      return 0;
}
