int main()
{
      int i=1,n;
      printf("enter n number");
      scanf("%d",&n);
      while(i<=n)
      {
            printf("%d\t",i);
            i++;
      }
      return 0;
}
