int main()
{
      int i=1;
      while(i<=10)
      {
            printf("%d\t",i*i*i);
            i++;
      }
      return 0;
}
