int main()
{
      int i=1,n;
      printf("enter a number");
      scanf("%d",&n);
      while(i<=10)
      {
            printf("%d\t",n*i);
            i++;
      }
}
