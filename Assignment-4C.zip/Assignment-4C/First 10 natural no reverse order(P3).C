#include<stdio.h>
int main()
{
      int i=1;
      while(i<=10)
      {
      printf("%d\n",11-i);
            i++;
      }
      return 0;
}
