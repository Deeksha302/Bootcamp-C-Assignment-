int main()
{
int i=1;
while(i<=10)
{
printf("%d\t",22-(2*i));
i++;
}
return 0;
}
