int main()
{
      int i=0;
      while(i<5)
      {
            printf(" MysirG\n");
            i++;
      }
      return 0;
}
