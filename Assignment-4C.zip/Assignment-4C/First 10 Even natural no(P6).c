int main()
{
      int i=1;
      while(i<=10)
      {
            printf("%d\t",i*2);
            i++;
      }
      return 0;
}
