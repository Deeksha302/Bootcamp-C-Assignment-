#include<stdio.h>
int main()
{
      int a,b;
      printf("enter any two number");
      scanf("%d%d",&a,&b);
      if(a<=b && b>a)
            printf("b is greater  number");
      else
            printf("a is greater number");
      return 0;
}
