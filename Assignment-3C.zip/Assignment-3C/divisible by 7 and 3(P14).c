int main()
{
      int x;
      printf("enter any number");
      scanf("%d",&x);
      if(x%7)
            printf("divisible by 3");
      else
            if(x%3)
            printf("divisible by  7");
      else
            printf("divisible by 3 and 7");
      return 0;
}
