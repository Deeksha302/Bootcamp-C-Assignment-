#include<stdio.h>
int main()
{
      int n;
      printf("enter a number");
      scanf("%d",&n);
      if(n>99 &&n<1000)
      printf("Three digit number");
      else
            printf("Not-Three digit number");

      return 0;
}
