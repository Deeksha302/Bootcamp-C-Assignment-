int  main()
{
      int i=1;
      while(i<=10)
      {
            printf("MysirG\n");
      i++;
      }
      printf("\n");
      return 0;
}
