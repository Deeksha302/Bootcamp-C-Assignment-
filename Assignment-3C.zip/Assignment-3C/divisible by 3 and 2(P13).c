int main()
{
      int x;
      printf("enter any number");
      scanf("%d",&x);
            if(x%3)
            printf("divisible by 2");
      else
            if(x%2)
            printf("divisible  3");
      else
            printf("divisible 2 and 3");
      return 0;
}
