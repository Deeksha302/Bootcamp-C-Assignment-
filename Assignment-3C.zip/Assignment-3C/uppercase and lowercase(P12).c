#include<stdio.h>
int main()
{
  char ch='G';
      if((65<=ch) &&  (ch<=90))
            printf("'%c' is Uppercase",ch);
     if((97<=ch )&& (ch<=122))
            printf(" '%c'  lowercase",ch);
     return 0;
}
