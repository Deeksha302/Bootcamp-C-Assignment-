#include<stdio.h>
int main()
{
      int a,b,c,disc;
      printf("enter three number");
      scanf("%d%d%d",&a,&b,&c);
       disc =b*b - 4*a*c;
      if(disc > 0)
            printf("Real & distinct");
           else if(disc < 0)
                      printf(" Roots is imagnary");
                 else
                      printf("Real & Equal");
      return 0;
}
