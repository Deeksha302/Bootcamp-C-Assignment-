int main()
{
      int h,e,m,s,ss,marks;
      float percentage;
      printf("enter a number");
      scanf("%d%d%d%d%d",&h,&e,&m,&s,&ss);
    marks=h+e+m+s+ss;
    printf("total marks=%d", marks);
    printf("\n");
      percentage= marks/5;
      printf("percentage is=%f",percentage);
      printf("\n");
       if(marks>=165)
            printf("student is pass");
            else
            printf("student is fail");
            printf("\n");
            if(percentage>=33 && percentage<=50)
                  printf("Division is Third");
            else
            if(percentage>=60)
                  printf("Division is First");
            else
                  printf("Division is second");
      return 0;
}
