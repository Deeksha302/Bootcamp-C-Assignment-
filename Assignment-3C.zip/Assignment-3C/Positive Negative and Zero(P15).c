int main()
{
      int x;
      printf("enter any number");
      scanf("%d",&x);
      if(x>=0)
            printf("positive");
            else
                  printf("Negative ");

      return 0;
}
