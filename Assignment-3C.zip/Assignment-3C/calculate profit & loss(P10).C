#include<stdio.h>
main()
{
      int sprice,cprice,amount,profit ,loss;
      printf("enter a cost price \n selling price\n");
      scanf("%d%d",&sprice,&cprice);
      if(sprice<cprice)
      {
      amount= sprice-cprice;
            printf("profit amount=%d", amount);
      }else
                  if(cprice<sprice)
                  {
                  amount= cprice-sprice;
                      printf("loss amount=%d", amount);
                  }else
                  printf("no profit and no loss ");
            return 0;
}
